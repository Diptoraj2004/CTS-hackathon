# Applying this fix

## Root causes found (not just pydantic)

1. **No pinned Python version anywhere in the repo.** `numpy==1.26.4` and
   `pyarrow==18.1.0` in requirements.txt don't ship wheels past Python 3.12.
   Fresh Colab runtimes and most people's local Python are 3.12/3.13 by
   default now, so `pip install` falls back to building numpy from source —
   slow, and it fails on most machines. That's *why* you were force-installing
   Python 3.11 and rebuilding the venv every session. `.python-version` +
   `setup.sh` fix this once, permanently, per machine.
2. **Four requirements.txt files, one source of truth.**
   `requirements.txt`, `backend/rag/requirements.txt`,
   `backend/app/requirements.txt`, `backend/safety/requirements.txt` all
   duplicate overlapping pins. This is exactly how the pydantic pin drifted
   (2.10.4 in some files, patched to 2.12.5 by hand, easy to miss one). Keep
   one root `requirements.txt`; delete the rest.
3. **`sentence-transformers==2.5.1` imports `cached_download` from
   `huggingface_hub`, a symbol removed in huggingface_hub 0.20+.** Nothing in
   requirements.txt pins huggingface_hub, so pip is free to resolve a version
   that breaks `import sentence_transformers` outright
   (`ImportError: cannot import name 'cached_download'`). Added
   `huggingface_hub==0.19.4` explicitly. This may not have bitten you yet
   depending on what else pulled it in as a transitive pin — worth confirming
   on a clean install rather than assuming it's fine.
4. **Two nested READMEs point at paths that don't exist:**
   `backend/rag/README.md` says `pip install -r backend\rag\requirements.txt`
   (Windows-style backslashes, wrong for the bash example around it), and
   `backend/app/README.md` says `pip install -r backend/requirements.txt`,
   which isn't a real path (`backend/app/requirements.txt` is). Both should
   just say `pip install -r requirements.txt` from the repo root once the
   consolidation in step 2 is done.

## Steps

```bash
# from your local clone of https://github.com/Diptoraj2004/CTS-hackathon
cp /path/to/cts-hackathon-fix/requirements.txt .
cp /path/to/cts-hackathon-fix/.python-version .
cp /path/to/cts-hackathon-fix/setup.sh .
cp /path/to/cts-hackathon-fix/Dockerfile .
chmod +x setup.sh

rm backend/rag/requirements.txt backend/app/requirements.txt backend/safety/requirements.txt
# then edit backend/rag/README.md and backend/app/README.md:
# replace their pip install line with: pip install -r ../../requirements.txt
# (adjust relative path per file's location)

git add -A
git status   # check the diff before committing
git commit -m "fix: pin Python 3.11, consolidate requirements, pin huggingface_hub"
git push
```

Teammates then just do, on any machine or fresh Colab:

```bash
git pull
bash setup.sh
source .venv311/bin/activate
```

or, to skip local Python entirely:

```bash
docker build -t cts-hackathon .
docker run -p 8000:8000 --env-file .env cts-hackathon
```

## Still unverified

- Whether huggingface_hub 0.19.4 is compatible with your currently-pinned
  `transformers`/`tokenizers` (not in requirements.txt — check if something
  else installs them transitively and pins a floor above 0.19.4, which would
  conflict).
- Whether `pydantic==2.12.5` (already in your zip) actually holds under
  `presidio-analyzer==2.2.364` and `spacy==3.8.0` together — your log showed
  the import check pass, but that's not the same as an end-to-end request
  through the FastAPI app. Run one real `/query` after `docker build` or
  after `setup.sh` before calling this closed.
