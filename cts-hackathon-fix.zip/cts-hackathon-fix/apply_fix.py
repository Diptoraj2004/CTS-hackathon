#!/usr/bin/env python3
"""
Applies the CTS hackathon env fix on top of a checked-out repo.
Idempotent — safe to run more than once.

Usage (from inside the extracted fix zip, with the repo cloned alongside):
    python apply_fix.py /content/CTS-hackathon
"""
import shutil
import sys
from pathlib import Path

PATCH_DIR = Path(__file__).resolve().parent


def apply(repo: Path) -> None:
    if not repo.exists():
        raise FileNotFoundError(f"Repo not found: {repo}")

    # 1. Drop in the fixed root files.
    for name in ["requirements.txt", ".python-version", "setup.sh", "Dockerfile"]:
        src = PATCH_DIR / name
        dst = repo / name
        shutil.copy2(src, dst)
        print(f"✓ wrote {dst}")
    (repo / "setup.sh").chmod(0o755)

    # 2. Remove the duplicate/drifting requirements files.
    for rel in [
        "backend/rag/requirements.txt",
        "backend/app/requirements.txt",
        "backend/safety/requirements.txt",
    ]:
        p = repo / rel
        if p.exists():
            p.unlink()
            print(f"✓ removed duplicate {rel}")
        else:
            print(f"  (already removed) {rel}")

    # 3. Fix the two broken README install paths.
    fixes = [
        (
            repo / "backend/rag/README.md",
            "python -m pip install -r backend\\rag\\requirements.txt",
            "python -m pip install -r ../../requirements.txt",
        ),
        (
            repo / "backend/app/README.md",
            "pip install -r backend/requirements.txt",
            "pip install -r ../../requirements.txt",
        ),
    ]
    for path, old, new in fixes:
        if not path.exists():
            print(f"  (skip, not found) {path}")
            continue
        text = path.read_text(encoding="utf-8")
        if old in text:
            path.write_text(text.replace(old, new), encoding="utf-8")
            print(f"✓ fixed broken install path in {path}")
        elif new in text:
            print(f"  (already fixed) {path}")
        else:
            print(f"  ⚠ expected line not found in {path} — check it by hand")

    print("\nDone. Review with: git -C", repo, "status")


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/content/CTS-hackathon")
    apply(target)
