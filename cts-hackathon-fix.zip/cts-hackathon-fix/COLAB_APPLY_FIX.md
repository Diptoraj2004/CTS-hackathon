# Colab: apply the env fix, then run calibration

Run these in order, in the same Colab session where `/content/CTS-hackathon`
is already your git clone (same assumption `calib/COLAB_CALIBRATION.md`
makes — git remote + credentials already configured in that session).

## Cell 1 — upload `cts-hackathon-fix.zip` and apply it

```python
%cd /content/CTS-hackathon

from google.colab import files
import os, zipfile, shutil, subprocess, sys

uploaded = files.upload()
zips = [f for f in uploaded if f.lower().endswith('.zip')]
if not zips:
    raise FileNotFoundError('Upload cts-hackathon-fix.zip.')
patch_zip = zips[0]

extract = '/tmp/cts_env_fix'
shutil.rmtree(extract, ignore_errors=True)
os.makedirs(extract, exist_ok=True)
with zipfile.ZipFile(patch_zip) as z:
    z.extractall(extract)

# handle both "zip contains files directly" and "zip contains one wrapper folder"
root = extract
if not os.path.exists(os.path.join(root, 'apply_fix.py')):
    dirs = [os.path.join(extract, d) for d in os.listdir(extract)
            if os.path.isdir(os.path.join(extract, d))]
    root = next((d for d in dirs if os.path.exists(os.path.join(d, 'apply_fix.py'))), None)
if not root:
    raise FileNotFoundError('Could not find apply_fix.py in the uploaded zip.')

repo = '/content/CTS-hackathon'
subprocess.run([sys.executable, os.path.join(root, 'apply_fix.py'), repo], check=True)

subprocess.run(['git', 'add', '-A'], cwd=repo, check=True)
subprocess.run(['git', 'diff', '--cached', '--name-status'], cwd=repo, check=True)

subprocess.run([
    'git', 'commit', '-m',
    'fix: pin Python 3.11, single requirements.txt, pin huggingface_hub, fix README paths'
], cwd=repo, check=False)
subprocess.run(['git', 'push'], cwd=repo, check=True)
print('Pushed env fix.')
```

Check the printed `git diff --cached` output before it commits — confirm it's
only touching `requirements.txt`, `.python-version`, `setup.sh`, `Dockerfile`,
the three deleted `backend/*/requirements.txt`, and the two README lines.

## Cell 2 — rebuild the environment from the fixed requirements

```python
%cd /content/CTS-hackathon
!bash setup.sh
```

This replaces every earlier "recreate venv / diagnose / patch pydantic by
hand" cell — one script, pinned Python 3.11, one requirements.txt, done.

If `bash setup.sh` can't find `python3.11` at all (rare on Colab, more likely
on a teammate's Windows laptop with no apt), tell them to use the `Dockerfile`
instead, or install Python 3.11 via pyenv/the python.org installer first.

## Cell 3 — now run calibration

Once Cell 2 finishes clean, proceed straight into
`calib/COLAB_CALIBRATION.md`'s own Cell 1 (upload the calibration zip) —
unchanged, no edits needed there. Its Cell 2 (`pip install -q -r
requirements.txt`) now installs from the single consolidated file instead of
a possibly-stale one, so it'll pick up the pinned `huggingface_hub` too.
